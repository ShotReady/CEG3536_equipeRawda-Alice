Core/Src/fsm.o: ../Core/Src/fsm.s ../Core/Src/registres.inc
../Core/Src/registres.inc:
