Core/Src/estop.o: ../Core/Src/estop.s ../Core/Src/registres.inc
../Core/Src/registres.inc:
