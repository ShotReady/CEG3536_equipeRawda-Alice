Core/Src/buttons.o: ../Core/Src/buttons.s ../Core/Src/registres.inc
../Core/Src/registres.inc:
