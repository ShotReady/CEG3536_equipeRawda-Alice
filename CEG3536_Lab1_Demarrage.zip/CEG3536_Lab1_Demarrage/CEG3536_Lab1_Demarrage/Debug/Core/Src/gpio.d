Core/Src/gpio.o: ../Core/Src/gpio.s ../Core/Src/registres.inc
../Core/Src/registres.inc:
