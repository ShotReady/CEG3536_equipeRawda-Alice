Core/Src/main.o: ../Core/Src/main.s ../Core/Src/registres.inc
../Core/Src/registres.inc:
